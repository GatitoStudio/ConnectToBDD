Prérequis : 
Avoir un serveur web et MYSQL.

1)Remplis le fichier php avec les infos de ta base 
2) Depuis unity donne le lien COMPLET , exemple 127.0.0.1/login.php
